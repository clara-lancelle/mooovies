-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : ven. 20 oct. 2023 à 20:58
-- Version du serveur : 8.0.34-0ubuntu0.22.04.1
-- Version de PHP : 8.1.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `dbmooovies`
--

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE `category` (
  `id` int NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Romance'),
(2, 'Drama'),
(3, 'Thriller'),
(4, 'Action');

-- --------------------------------------------------------

--
-- Structure de la table `movie`
--

CREATE TABLE `movie` (
  `id` int NOT NULL,
  `author_id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `producer` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `synopsis` text COLLATE utf8mb4_general_ci NOT NULL,
  `category_id` int NOT NULL,
  `scenarist` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `production_company` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `release_year` varchar(4) COLLATE utf8mb4_general_ci NOT NULL,
  `poster` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `movie`
--

INSERT INTO `movie` (`id`, `author_id`, `title`, `producer`, `synopsis`, `category_id`, `scenarist`, `production_company`, `release_year`, `poster`) VALUES
(1, 1, 'Titanic', 'James Cameron ', 'In the 1997 film \"Titanic,\" Jack Dawson, a struggling artist, and Rose DeWitt Bukater, an aristocratic young woman engaged to a wealthy man, meet and fall in love on the ill-fated RMS Titanic. Their love story unfolds against the backdrop of the ship\'s grandeur and luxury, but the Titanic\'s collision with an iceberg leads to a tragic and chaotic sinking. Jack and Rose must navigate the chaos, social class divisions, and the impending disaster to be together. The film alternates between their love story and the dramatic events of the ship\'s sinking. The climax involves the Titanic\'s final moments as it sinks into the icy waters of the North Atlantic, leading to the loss of many lives. Ultimately, Jack sacrifices himself to save Rose, and she survives by clinging to debris until rescued by a lifeboat. The film is known for its epic romance, stunning visuals, and historical tragedy, making it one of the most iconic movies in cinematic history.', 2, 'James Cameron', ' 20th Century Fox and Paramount Pictures', '1997', ''),
(2, 1, 'Jaws', 'Richard D. Zanuck and David Brown', '\"Jaws\" is a 1975 thriller film directed by Steven Spielberg. It tells the story of a resort town terrorized by a great white shark. The local police chief, a marine biologist, and a professional shark hunter team up to hunt down the deadly predator before it can claim more victims.', 3, 'Peter Benchley (based on his novel) and Carl Gottlieb', 'Universal Pictures and Zanuck/Brown Productions', '1975', ''),
(4, 1, 'Fight Club', 'Art Linson and Ceán Chaffin', '\"Fight Club\" is a 1999 psychological thriller film directed by David Fincher. The movie follows the story of an insomniac office worker who forms an underground fight club as a form of male bonding and rebellion against the conformity of consumer culture. The club evolves into something much darker and complex, challenging the protagonist\'s sense of reality.', 3, 'Jim Uhls (based on the novel by Chuck Palahniuk)', ' Fox 2000 Pictures and Regency Enterprises', '1999', ''),
(5, 3, 'The Shawshank Redemption', 'Frank Darabont', 'Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.', 2, 'Stephen King', 'Castle Rock Entertainment', '1994', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(300) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'clara', '$2y$10$zK/x37ZONSpyGE75JjzPK.clv4sDexdOhglWBt2LGDoNqiUzoLBLy\" bool(false) string(60) \"$2y$10$DF1tegexaBE3/SNF55TU5.8CyPw4jh6tO9w1yY1q7kYZbU48/3.iy'),
(3, 'tutu', '$2y$10$jP0ieY3lzEyz2ecXFSjcQeOjnf2QLUVNcR86FJ9r2g7dWKOio1rdu'),
(4, 'titi', '$2y$10$Hd01XjUfTbs1osE7Nh45FOtXFa/H91vV.VjJaxHRDtGwT74jMhaEq');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `author_id` (`author_id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `movie`
--
ALTER TABLE `movie`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `movie`
--
ALTER TABLE `movie`
  ADD CONSTRAINT `author_id` FOREIGN KEY (`author_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `category_id` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
